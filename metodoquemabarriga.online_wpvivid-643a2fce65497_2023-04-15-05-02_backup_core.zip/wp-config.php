<?php


/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'u775725954_aggcB' );

/** Database username */
define( 'DB_USER', 'u775725954_JyN9E' );

/** Database password */
define( 'DB_PASSWORD', 'lzRE7vUfmi' );

/** Database hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'MH-e41W29e]G]iC5LX@3=cv2#.<LDhh[S&iraE TWt#a $f!N]oR/P8W14OiAXYF' );
define( 'SECURE_AUTH_KEY',   '&f|5D~%3o5jHxG?C`r+]Pw<E*I;<VXyfIyqP1FS,|N,6@X}ACf2s5f1l_<WQBvtu' );
define( 'LOGGED_IN_KEY',     '>Z/<(~^J/rTQm`)5,m6ozL |[^=o2Sgb_x6-{KpS@AnGwYUc{fHiBrUPXRx{R^Q[' );
define( 'NONCE_KEY',         'pKs2A`(X-[tTgI*MrrmyvVO~_1h)x`n*bq834dQYH^vprY~Bf@S* E#f^#XJ<v)3' );
define( 'AUTH_SALT',         ' 1MM&@?SINadv 5Bkb?MLS hG]?DNwjqMqYh{)7ZUFNrhQ3%w6&6CHsZC|3*D7Qb' );
define( 'SECURE_AUTH_SALT',  '#NCKQ:tfe4U9L{UE>uc:Wj7&Aeu-yz,mM)t}f!378&yG;uH$YT_7E_Ie~}PXnS*!' );
define( 'LOGGED_IN_SALT',    '{Q1,Tp(fv6G8@Aeh[ix]s[&hCVZC90?Q,s`9,RRUr~zGAzfR;#7:w3K!vaDR$unu' );
define( 'NONCE_SALT',        'f8/d:O{jLFcOxK T`{~OoC11u3-^8bl1Ed?EeY1*pO3Y?1w)G1l5ki-g[|id{*G{' );
define( 'WP_CACHE_KEY_SALT', '(mqU) hK)M}U|rv$1z@.dMd%0Xg9x&AZ<{}]3Lh^n;`eNd0an/GlxN>-`|^{92Ty' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );


/* Add any custom values between this line and the "stop editing" line. */



define( 'FS_METHOD', 'direct' );
define( 'WP_AUTO_UPDATE_CORE', 'minor' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
